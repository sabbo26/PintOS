#include <stdio.h>
#include <stdlib.h>

typedef int64_t real;

real int_to_fixed(int n);
int fixed_to_nearest_int(real x);
int fixed_to_int(real x);
real mul_two_fixed(real x,real y);
real add_two_fixed(real x,real y);
real mul_fixed_int(real x,int n);
real div_two_fixed(real x,real y);
real div_fixed_int(real x,int n);
real add_fixed_int(real x, int n);
real sub_fixed_int(real x, int n);
real sub_two_fixed(real x, real y);
