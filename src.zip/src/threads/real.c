#define fraction 16384
#include "real.h"

/* fixed point representation */

//Convert n to fixed point: 	n * f
real int_to_fixed(int n)
{
    real r = ((n) * fraction);
    return r;
}

//Convert x to integer (rounding to nearest):
int fixed_to_nearest_int(real x)
{
   if(x >= 0)
    return (((x) + (fraction / 2)) / fraction );
   else
    return (((x) - (fraction / 2)) / fraction );
}

//Convert x to integer (rounding toward zero)
int fixed_to_int(real x)
{
    return ((x) / fraction);
}

real mul_two_fixed(real x,real y)
{
    real r = ((int64_t)x) * y / fraction;
    return r;
}

// multiply of fixed point with integer
real mul_fixed_int(real x,int n)
{
    real r = x*n;
    return r;
}
//division two fixed point
real div_two_fixed(real x,real y)
{
    real r = (((int64_t)(x)) * fraction) / y;
    return r;
}

// divide of fixed point with integer
real div_fixed_int(real x,int n)
{
    real r = x/n;
    return r;
}
//Add x and y: 	x + y
real add_two_fixed(real x, real y){
    real r = x+y;
    return r;
}

// add fixed point to integer_into_fixed_point
real add_fixed_int(real x, int n){
    real r = x + n * fraction;
    return r;
}

// subtract fixed point to integer_into_fixed_point
real sub_fixed_int(real x, int n){
  real r = x - n * fraction;
    return r;
}


 real sub_two_fixed(real x, real y){
  real r = x-y;
    return r;
}
